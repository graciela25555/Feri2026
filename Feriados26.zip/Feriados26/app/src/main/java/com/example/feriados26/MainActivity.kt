package com.example.feriados26

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        // BOTONES
        val btnEnero = findViewById<Button>(R.id.btnEnero)
        val btnFebrero = findViewById<Button>(R.id.btnFebrero)
        val btnMarzo = findViewById<Button>(R.id.btnMarzo)
        val btnAbril = findViewById<Button>(R.id.btnAbril)
        val btnMayo = findViewById<Button>(R.id.btnMayo)
        val btnJunio = findViewById<Button>(R.id.btnJunio)
        val btnJulio = findViewById<Button>(R.id.btnJulio)
        val btnAgosto = findViewById<Button>(R.id.btnAgosto)
        val btnSetiembre = findViewById<Button>(R.id.btnSetiembre)
        val btnOctubre = findViewById<Button>(R.id.btnOctubre)
        val btnNoviembre = findViewById<Button>(R.id.btnNoviembre)
        val btnDiciembre = findViewById<Button>(R.id.btnDiciembre)

        // CLICK PARA ABRIR ACTIVITIES
        btnEnero.setOnClickListener {
            startActivity(Intent(this, EneroActivity::class.java))
        }
        btnFebrero.setOnClickListener {
            startActivity(Intent(this, FebreroActivity::class.java))
        }
        btnMarzo.setOnClickListener {
            startActivity(Intent(this, MarzoActivity::class.java))
        }
        btnAbril.setOnClickListener {
            startActivity(Intent(this, AbrilActivity::class.java))
        }
        btnMayo.setOnClickListener {
            startActivity(Intent(this, MayoActivity::class.java))
        }
        btnJunio.setOnClickListener {
            startActivity(Intent(this, JunioActivity::class.java))
        }
        btnJulio.setOnClickListener {
            startActivity(Intent(this, JulioActivity::class.java))
        }
        btnAgosto.setOnClickListener {
            startActivity(Intent(this, AgostoActivity::class.java))
        }
        btnSetiembre.setOnClickListener {
            startActivity(Intent(this, SetiembreActivity::class.java))
        }
        btnOctubre.setOnClickListener {
            startActivity(Intent(this, OctubreActivity::class.java))
        }
        btnNoviembre.setOnClickListener {
            startActivity(Intent(this, NoviembreActivity::class.java))
        }
        btnDiciembre.setOnClickListener {
            startActivity(Intent(this, DiciembreActivity::class.java))
        }
    }
}
